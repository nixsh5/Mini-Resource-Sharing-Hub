document.getElementById('upload-form')?.addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Resource uploaded successfully!');
});

document.getElementById('login-form')?.addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Login successful!');
});
